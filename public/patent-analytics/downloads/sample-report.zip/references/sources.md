# Sources and Methodology

## Patent
4-amino substituted-6-aryl/heteroaryl substituted-2-methylsulfanyl-pyrimidine-5-carbaldehyde intermediates
Patent number: US07314934 (US7314934B2)
Source: https://patents.google.com/patent/US7314934B2/en

## Extraction methodology
1. Chemical structure diagrams were extracted from the patent's figures using
   DECIMER (open-source optical chemical structure recognition), the same
   tool independently benchmarked on real patent images in the RSC paper
   "Comparing software tools for optical chemical structure recognition."
2. Each extracted structure was passed through an automated chemical sanity
   gate: disconnected noise fragments (e.g. stray metal atoms picked up from
   page furniture) are identified and removed; anything containing an
   unrecognized disconnected fragment is flagged for review rather than
   auto-cleaned.
3. Each cleaned structure was independently cross-checked against Google
   Patents' own separately-computed chemical compound data for this patent
   (SMILES + InChIKey, extracted by Google's own pipeline -- not ours).
   Independent agreement between our extraction and this second source is
   what earns a structure "AUTO-VERIFIED" status.

## Measured accuracy (real validation, not a projected estimate)
Tested against the OSRA USPTO validation set (5,719 real chemical structure
images from real US patents, with expert-corrected ground-truth structures)
plus real full-text cross-checks against 41 real, distinct patents:
  - 100-structure random sample: 57% raw exact-match, rising to 63% after
    automated cleanup.
  - Of everything independently cross-check CONFIRMED (54 of the 100), 100%
    were verified correct against ground truth -- 0 false positives.
  - Everything not independently confirmed is routed to manual review, never
    silently presented as fact.

## This report
9 structure(s) extracted from this patent. 8 auto-verified
(passed cleanup AND independent cross-check). 1 flagged for
manual review -- shown as our best extraction, not asserted as confirmed.

## Scope and limitations
- This report identifies chemical structures present in the patent. It does
  not assert legal conclusions (infringement, validity, claim scope,
  disclosure/enablement) -- those require professional legal review.
- Structures flagged "Needs review" should be checked against the source
  figure (included alongside each entry) before being relied upon.
